
<!-- ================================================ jQuery Library ================================================ -->
<script type="text/javascript" src="<?php echo base_url()?>front_assets/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>front_assets/js/jquery.validate.min.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>front_assets/js/jquery.treegrid.js"></script>
<!-- ================================================ Bootstrap Core JavaScript File ================================================ -->
<script src="<?php echo base_url()?>front_assets/js/bootstrap/bootstrap.min.js"></script>

<!-- ================================================ Plugin.js - Some Specific JS codes for Plugin Settings ================================================ -->
<script type="text/javascript" src="<?php echo base_url()?>front_assets/js/plugins.js"></script>

<!-- ================================================ Data Tables================================================ -->
<script src="<?php echo base_url()?>front_assets/js/datatables/datatables.min.js"></script>



<!-- ================================================
Bootstrap Select
================================================ -->
<script type="text/javascript" src="<?php echo base_url() ?>front_assets/js/bootstrap-select/bootstrap-select.js"></script>

<!-- ================================================
Bootstrap Toggle
================================================ -->
<script type="text/javascript" src="<?php echo base_url() ?>front_assets/js/bootstrap-toggle/bootstrap-toggle.min.js"></script>
