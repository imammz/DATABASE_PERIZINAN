<!-- START SIDEPANEL -->
<div role="tabpanel" class="sidepanel">

  <!-- Tab panes -->
  <div class="tab-content">

    <!-- Start Notification -->
    <div role="tabpanel" class="tab-pane active" id="today">

      <div class="gn-title">Notification</div>
	  <p>Cek Setiap Notifikasi Yang Anda Miliki</p>

      <ul class="list-w-title">
        <li>
          <a href="#">
            <span class="label label-danger">ORDER</span>
            <span class="date">9 hours ago</span>
            <h4>Stock Opname Update</h4>
          </a>
        </li>
        <li>
          <a href="#">
            <span class="label label-success">Transfer Out</span>
            <span class="date">14 hours ago</span>
            <h4>Stock Opname Update</h4>
          </a>
        </li>
        <li>
          <a href="#">
            <span class="label label-info">Transfer In</span>
            <span class="date">at 2:30 PM</span>
            <h4>Stock Transfer in</h4>
          </a>
        </li>
      </ul>

    </div>
    <!-- Start Notification -->

</div>
</div>
<!-- END SIDEPANEL -->
