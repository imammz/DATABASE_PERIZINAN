<!-- Start Footer -->
<div class="footer">
  <div class="text-left"> Copyright © 2015  BIZON.ID.</div>
</div>
<!-- End Footer -->
</body>
</html>
